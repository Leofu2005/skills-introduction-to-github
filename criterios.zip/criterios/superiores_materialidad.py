import pandas as pd
import numpy as np
import unicodedata

def normalizar_columnas(df):
    """Normaliza nombres de columnas para consistencia"""
    def normalizar_texto(texto):
        texto = ''.join(c for c in unicodedata.normalize('NFD', str(texto))
                       if unicodedata.category(c) != 'Mn')
        return texto.lower().strip().replace(' ', '_').replace('.', '').replace('-', '_')
    df.columns = [normalizar_texto(col) for col in df.columns]
    return df

def detectar_superiores_materialidad(input_excel_path: str, output_excel_path: str, materialidad=11000):
    df = pd.read_excel(input_excel_path)
    df = normalizar_columnas(df)

    df["fecha"] = pd.to_datetime(df["fecha"], errors="coerce").dt.strftime("%d/%m/%Y")
    df["debe"] = pd.to_numeric(df["debe"], errors="coerce").fillna(0)
    df["haber"] = pd.to_numeric(df["haber"], errors="coerce").fillna(0)

    condicion = (df["debe"] > materialidad) | (df["haber"] > materialidad)
    df_filtrado = df[condicion].copy()

    columnas_salida = ["asiento", "fecha", "concepto", "cuenta", "debe", "haber"]
    if "nombre_cuenta" in df.columns:
        columnas_salida.insert(4, "nombre_cuenta")
    if "usuario" in df.columns:
        columnas_salida.append("usuario")

    df_final = df_filtrado[columnas_salida]
    df_final = df_final[~df_final["asiento"].astype(str).str.contains("total", case=False, na=False)]

    df_final.to_excel(output_excel_path, index=False)
