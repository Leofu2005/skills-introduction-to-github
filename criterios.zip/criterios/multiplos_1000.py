import pandas as pd
import unicodedata

def normalizar_columnas(df):
    """Normaliza nombres de columnas para consistencia"""
    def normalizar_texto(texto):
        texto = ''.join(c for c in unicodedata.normalize('NFD', str(texto))
                       if unicodedata.category(c) != 'Mn')
        return texto.lower().strip().replace(' ', '_').replace('.', '').replace('-', '_')
    df.columns = [normalizar_texto(col) for col in df.columns]
    return df

def detectar_multiplos_1000(input_excel_path: str, output_excel_path: str):
    df = pd.read_excel(input_excel_path)
    df = normalizar_columnas(df)

    df["fecha"] = pd.to_datetime(df["fecha"], errors="coerce").dt.strftime('%d/%m/%Y')
    df["debe"] = pd.to_numeric(df["debe"], errors="coerce").fillna(0)
    df["haber"] = pd.to_numeric(df["haber"], errors="coerce").fillna(0)

    condicion = ((df["debe"] % 1000 == 0) & (df["debe"] != 0)) | ((df["haber"] % 1000 == 0) & (df["haber"] != 0))
    df_filtrado = df[condicion].copy()

    columnas_salida = ["asiento", "fecha", "concepto", "cuenta", "debe", "haber"]
    if "nombre_cuenta" in df.columns:
        columnas_salida.insert(4, "nombre_cuenta")
    if "usuario" in df.columns:
        columnas_salida.append("usuario")

    df_final = df_filtrado[columnas_salida]
    df_final.to_excel(output_excel_path, index=False)
    print(f"Archivo generado: {output_excel_path}")
