
import pandas as pd
import unicodedata

def normalizar_columnas(df):
    """Normaliza nombres de columnas para consistencia"""
    def normalizar_texto(texto):
        texto = ''.join(c for c in unicodedata.normalize('NFD', str(texto))
                       if unicodedata.category(c) != 'Mn')
        return texto.lower().strip().replace(' ', '_').replace('.', '').replace('-', '_')
    df.columns = [normalizar_texto(col) for col in df.columns]
    return df

def detectar_asientos_faltantes(input_excel_path: str, output_excel_path: str):
    # Leer el archivo de entrada
    df = pd.read_excel(input_excel_path)
    df = normalizar_columnas(df)

    # Convertir la columna "asiento" a numérico por seguridad
    df["asiento"] = pd.to_numeric(df["asiento"], errors="coerce")
    asientos_unicos = sorted(df["asiento"].dropna().unique().astype(int))

    if not asientos_unicos:
        print("⚠️ No se encontraron asientos válidos.")
        return

    primer_asiento = asientos_unicos[0]
    ultimo_asiento = asientos_unicos[-1]

    # 1️⃣ Paso nuevo: revisar los saltos grandes entre asientos existentes
    for i in range(1, len(asientos_unicos)):
        anterior = asientos_unicos[i - 1]
        actual = asientos_unicos[i]
        salto = actual - anterior

        if salto > 30:
            print(f"⚠️ Advertencia: Salto de {salto - 1} asientos entre {anterior} y {actual}")

    # 2️⃣ Generar todos los asientos que deberían existir
    asientos_teoricos = list(range(primer_asiento, ultimo_asiento + 1))

    # 3️⃣ Comparar los reales vs. teóricos
    faltantes = sorted(set(asientos_teoricos) - set(asientos_unicos))

    # 4️⃣ Guardar los asientos faltantes en un Excel
    df_faltantes = pd.DataFrame({"asiento_faltante": faltantes})
    df_faltantes.to_excel(output_excel_path, index=False)

    print(f"✅ Archivo generado con {len(faltantes)} asientos faltantes: {output_excel_path}")
