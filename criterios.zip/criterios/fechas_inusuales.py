import pandas as pd
import os
import unicodedata

def normalizar_columnas(df):
    """Normaliza nombres de columnas para consistencia"""
    def normalizar_texto(texto):
        texto = ''.join(c for c in unicodedata.normalize('NFD', str(texto))
                       if unicodedata.category(c) != 'Mn')
        return texto.lower().strip().replace(' ', '_').replace('.', '').replace('-', '_')
    df.columns = [normalizar_texto(col) for col in df.columns]
    return df

def detectar_fechas_inusuales(input_excel_path: str, output_excel_path: str, festivos_path="festivos_mallorca_2024.xlsx"):
    if not os.path.exists(festivos_path):
        raise FileNotFoundError(f"Archivo de festivos no encontrado: {festivos_path}")

    df = pd.read_excel(input_excel_path)
    festivos = pd.read_excel(festivos_path)

    df = normalizar_columnas(df)
    festivos = normalizar_columnas(festivos)

    festivos["fecha"] = pd.to_datetime(festivos["fecha"], format="%d/%m/%Y", errors="coerce")
    df["fecha"] = pd.to_datetime(df["fecha"], format="%d/%m/%Y", errors="coerce")
    df["dia_semana"] = df["fecha"].dt.day_name()

    es_festivo = df["fecha"].isin(festivos["fecha"])
    es_findesemana = df["fecha"].dt.dayofweek >= 5
    df_inusuales = df[es_festivo | es_findesemana].copy()

    def extraer_cuentas(subdf, tipo):
        cuentas = (
            subdf.loc[subdf[tipo] != 0, "cuenta"]
            .dropna()
            .apply(lambda x: str(int(float(x))) if pd.notnull(x) else None)
            .unique()
        )
        return ",".join(cuentas) if len(cuentas) > 0 else None

    resultados = []

    for asiento, grupo in df_inusuales.groupby("asiento"):
        fila = {
            "asiento": asiento,
            "fecha": grupo["fecha"].iloc[0].strftime("%d/%m/%Y"),
            "dia_semana": grupo["dia_semana"].iloc[0],
            "concepto": grupo["concepto"].iloc[0],
            "saldo": f"{grupo['debe'].sum():,.2f}".replace(".", ","),
            "cuentas_debe": extraer_cuentas(grupo, "debe"),
            "cuentas_haber": extraer_cuentas(grupo, "haber"),
            "usuario": grupo["usuario"].dropna().unique()[0] if "usuario" in grupo.columns and grupo["usuario"].notna().any() else None
        }
        resultados.append(fila)

    df_final = pd.DataFrame(resultados)

    # Convertir columna "fecha" a datetime real para ordenar
    df_final["fecha"] = pd.to_datetime(df_final["fecha"], format="%d/%m/%Y", errors="coerce")

    # Ordenar cronológicamente
    df_final = df_final.sort_values(by="fecha")

    # Convertir columna "saldo" de texto a float
    df_final["saldo"] = (
        df_final["saldo"]
        .str.replace(".", "", regex=False)   # quitar puntos de mil
        .str.replace(",", ".", regex=False)  # cambiar coma decimal por punto
    )
    df_final["saldo"] = pd.to_numeric(df_final["saldo"], errors="coerce")

    # Volver a exportar el archivo ya limpio y ordenado
    df_final.to_excel(output_excel_path, index=False)
    print(f"Archivo generado: {output_excel_path}")