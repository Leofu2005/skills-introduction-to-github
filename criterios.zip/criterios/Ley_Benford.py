import pandas as pd
import numpy as np
import unicodedata

def normalizar_columnas(df):
    """Normaliza nombres de columnas para consistencia"""
    def normalizar_texto(texto):
        texto = ''.join(c for c in unicodedata.normalize('NFD', str(texto))
                       if unicodedata.category(c) != 'Mn')
        return texto.lower().strip().replace(' ', '_').replace('.', '').replace('-', '_')
    df.columns = [normalizar_texto(col) for col in df.columns]
    return df

def detectar_Ley_Benford(input_excel_path: str, output_excel_path: str):
    df = pd.read_excel(input_excel_path)
    df = normalizar_columnas(df)

    df["debe"] = pd.to_numeric(df["debe"], errors="coerce").fillna(0)
    df["haber"] = pd.to_numeric(df["haber"], errors="coerce").fillna(0)

    importes = pd.concat([df["debe"], df["haber"]])
    importes = importes[importes > 0]

    def primer_digito(x):
        return int(str(int(x))[0]) if x >= 1 else None

    primeros = importes.apply(primer_digito)
    conteo = primeros.value_counts().reindex(range(1, 10), fill_value=0)
    porcentaje_real = (conteo / conteo.sum()) * 100
    benford_esperado = {d: 100 * np.log10(1 + 1/d) for d in range(1, 10)}

    df_benford = pd.DataFrame({
        "digito": list(range(1, 10)),
        "porcentaje_esperado": [benford_esperado[d] for d in range(1, 10)],
        "porcentaje_real": [porcentaje_real.get(d, 0) for d in range(1, 10)]
    })

    df_benford.to_excel(output_excel_path, index=False)
    print(f"✅ Archivo generado: {output_excel_path}")
